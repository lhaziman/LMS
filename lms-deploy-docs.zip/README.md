# LMS Training App

Sebuah aplikasi Learning Management System (LMS) berbasis web untuk perusahaan yang mencakup:
- Manajemen pelatihan karyawan
- Pre-Test & Post-Test
- Approval training oleh HRD
- Role-based access (Employee dan HRD)

## Teknologi
- Backend: Node.js + Express + Sequelize + PostgreSQL
- Frontend: React + Vite + Tailwind CSS
- Auth: JWT
- Deployment: Render (backend), Vercel (frontend)

---

## Fitur
- Login & Register
- Dashboard training berdasarkan departemen
- Daftar pelatihan
- Pre-Test dan Post-Test otomatis
- Approval oleh HRD
- Kompetensi karyawan

---

## Instalasi Lokal

### 1. Clone Project
```bash
git clone https://github.com/username/lms-backend.git
cd lms-backend
```

### 2. Install Dependency
```bash
npm install
```

### 3. Setup .env
Buat file `.env` dari `.env.example`, lalu isi sesuai konfigurasi lokal atau Render.

### 4. Jalankan Server
```bash
node app.js
```

---

## Deployment

### Backend (Render)
1. Upload folder `lms-backend` ke GitHub
2. Masuk ke https://render.com, pilih **Web Service**
3. Set environment:
   - Build command: `npm install`
   - Start command: `node app.js`
4. Tambahkan Environment Variables dari `.env`

### Database
1. Buat PostgreSQL Database di Render
2. Salin credentials ke `.env`

---

### Frontend (Vercel)
1. Upload folder `lms-frontend` ke GitHub
2. Masuk ke https://vercel.com, pilih **New Project**
3. Build Command: `npm run build`
4. Output Directory: `dist`

Ubah URL API pada `authService.js`, `trainingService.js`, dll ke URL backend dari Render.

---

## Author
Pengembang: [Nama Anda]
